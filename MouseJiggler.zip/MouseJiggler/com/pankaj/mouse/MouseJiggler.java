package com.pankaj.mouse;

import java.awt.MouseInfo;
import java.awt.Robot;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.URL;

import javax.swing.AbstractButton;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JPanel;

/**
 * 
 * @author Pankaj Kumar Kaalyan
 * @version 1.0
 * @category Standalone
 *
 */
public class MouseJiggler extends Thread{

	private static JFrame jFrame = null;
	private static JCheckBox startJCheckBox = null;
	private static JPanel jPanel = null;
	private static AbstractButton abstractButton = null;
	private static boolean flag = false;
	
	public static void main(String[] args) {
		getGUI();
	}
	
	private static void getGUI(){
		jFrame = new JFrame("Mouse Jiggler");
		URL url = MouseJiggler.class.getResource("/Resources/icon.png");
		ImageIcon img = new ImageIcon(url);
		jFrame.setIconImage(img.getImage());
		jFrame.setSize(100,100);
		jFrame.setResizable(false);
	
		startJCheckBox = new JCheckBox("START");
		startJCheckBox.setVisible(true);
		
		jPanel = new JPanel();
		jPanel.setBorder(BorderFactory.createTitledBorder("Mouse Jiggle"));
		jPanel.add(startJCheckBox);
		
		jFrame.add(jPanel);
		jFrame.setVisible(true);
		jFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		startJCheckBox.addActionListener(actionListener);
		
	}
	
	// Action Listener for checked and Unchecked
	private static ActionListener actionListener = new ActionListener() {
	      public void actionPerformed(ActionEvent actionEvent) {
	        abstractButton = (AbstractButton) actionEvent.getSource();
	        boolean selected = abstractButton.getModel().isSelected();
	        System.out.println(selected);
	        if(selected){
	        	flag=true;
	        	new Thread(new MouseJiggler()).start();
	        }else{
	        	flag=false;
		        }
	        }
	};
	   
    public void run(){
    	try {
			Robot robot = new Robot();
			boolean check = false;
			while(flag){
				double x = MouseInfo.getPointerInfo().getLocation().getX();
				double y = MouseInfo.getPointerInfo().getLocation().getY();
				if(!check){
				robot.mouseMove((int)x+2,(int)y+2);
				check=true;
				}
				else{
				robot.mouseMove((int)x-2,(int)y-2);
				check=false;
				}	
				Thread.currentThread().sleep(1500);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
    }
}
